<?php

require_once '../../Config.php';
require_once HELPERS_URL . '/MusicaHelper.php';

$content = showProfile();

require_once LAYOUT_URL;