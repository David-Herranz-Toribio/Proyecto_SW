<?php

require_once '../../Config.php';
require_once HELPERS_URL . '/TiendaHelper.php';

$yo = isset($_SESSION['username']) ? $_SESSION['username'] : null;

$content = "<h1 class = 'texto_infor'> Productos </h1>";
$content .= showProducts($yo);

require_once LAYOUT_URL;