<footer class= "footer">
    <div class="music_player"><p> Reproductor de música </p></div>
</footer>