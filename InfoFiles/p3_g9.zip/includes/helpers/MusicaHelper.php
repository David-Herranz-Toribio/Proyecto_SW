<?php
require_once '../../Config.php';

function showProfile(){
    
    $html = "<p> Estas viendo tu musica </p>";

    return $html;
}